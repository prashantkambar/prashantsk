/* eslint-disable no-unused-vars */
// Make a copy of this file and save it as config.js (in the js directory).

// Set this to the base URL of your sample server, such as 'https://your-app-name.herokuapp.com'.
// Do not include the trailing slash. See the README for more information:

var SAMPLE_SERVER_BASE_URL = 'http://YOUR-SERVER-URL';

// OR, if you have not set up a web server that runs the learning-opentok-php code,
// set these values to OpenTok API key, a valid session ID, and a token for the session.
// For test purposes, you can obtain these from https://tokbox.com/account.

var API_KEY = '46109192';
var SESSION_ID = '1_MX40NjEwOTE5Mn5-MTUyNDkwMzQ2NTc4Nn5yY0dQUkxCUm1Nc1lHUmEwandlM2Q4OE9-fg';
var TOKEN = 'T1==cGFydG5lcl9pZD00NjEwOTE5MiZzaWc9YjUzMjYwNzQ4MGQwZTRjNGFjMDI0MTJlNGUwMmNkOWI0MWZmNGFhNzpzZXNzaW9uX2lkPTFfTVg0ME5qRXdPVEU1TW41LU1UVXlORGt3TXpRMk5UYzRObjV5WTBkUVVreENVbTFOYzFsSFVtRXdhbmRsTTJRNE9FOS1mZyZjcmVhdGVfdGltZT0xNTI0OTAzNTE1Jm5vbmNlPTAuMDE1NDA5NTc4NTgwNDQ0ODk0JnJvbGU9cHVibGlzaGVyJmV4cGlyZV90aW1lPTE1MjU1MDgyODAmaW5pdGlhbF9sYXlvdXRfY2xhc3NfbGlzdD0=';
