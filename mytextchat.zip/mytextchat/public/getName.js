var queryString;

var readParameters = function()
{

console.log('Getting parameters..');
let params = (new URL(location)).searchParams;
console.log('Query parameters: ', params.toString());

//  var html = '';
for (let p of params) {
  queryString = p.toString();
}
queryString = queryString.replace (/,/g, "");
alert(queryString);
}
