
//Make connection
var socket = io.connect('http://35.161.109.133:8080/');
var queryString = '';

//Query DOM
var message = document.getElementById('message');
handle = document.getElementById('handle'),
btn = document.getElementById('send'),
output = document.getElementById('output');
//user = localStorage.getItem("storageName");
//alert(user);

var readParameters = function()
{
    console.log('Getting parameters..');
    let params = (new URL(location)).searchParams;
    console.log('Query parameters: ', params.toString());

  //  var html = '';
    for (let p of params) {
      queryString += p.toString();
    }

    var splittedString = queryString.split(',');
    nameFromUrl = splittedString[0];
    nameFromUrl2 = splittedString[1];

    document.getElementById("handle").value = nameFromUrl;
    //alert(nameFromUrl);
    alert(nameFromUrl2);
}


//Emit events

btn.addEventListener('click',function(){
  socket.emit('chat', {
    message: message.value,
    handle: handle.value
  });
});

//Listen for events
socket.on('chat', function(data){
  if(data.handle == nameFromUrl || data.handle == nameFromUrl2){
  output.innerHTML+='<p><strong>' + data.handle + ':</strong>' + data.message + '</p>';
}
});
